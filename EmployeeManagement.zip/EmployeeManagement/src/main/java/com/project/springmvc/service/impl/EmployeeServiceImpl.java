package com.project.springmvc.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.project.springmvc.dao.impl.EmployeeDAOImpl;
import com.project.springmvc.entity.Employee;

//SERVICE IS THE MIDDLE LAYER
@Service//get from @repository and connects to @controller
@Transactional//database transaction
public class EmployeeServiceImpl {

	@Autowired
	private EmployeeDAOImpl employeeDAO1;
	
	public void createEmployee(Employee employee) 
	{
	
		
		employeeDAO1.createEmployee(employee);
			
	
		
	}
	
	@Transactional
	public List<Employee> getemps() 
	{
		
		return employeeDAO1.getEmployee();
	}

	@Transactional
	public void deleteemps(long theId)
	{
		employeeDAO1.deleteEmp(theId);
	}


	

}