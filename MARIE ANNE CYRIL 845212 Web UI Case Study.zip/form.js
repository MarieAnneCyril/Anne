function validation(){
	var name=document.register.name.value;
	var password=document.register.password.value;
	var number=document.register.number.value;
	
	if(name==null || name==""){
		alert("name cant be empty");
		return false;
	
}
if(password.length<6 || password.length>8){
	alert("password should be minimum of 6 character maximum of 8 character");
	return false;
}
if(number==null || number.length<10){
	alert("contact information is mandatory,give valid number");
	return false;
}
}